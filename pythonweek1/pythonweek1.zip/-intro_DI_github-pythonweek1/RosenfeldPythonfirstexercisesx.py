1

print("Hello world\nHello world\nHello world\nHello World")

2

results = (99 ^ 3) * 8


3

print(results)
print (5 > 3)
print(3==3)
print (3=="3")
print ("Hello" == "hello")

4

computer_brand= "Lenovo"
print ("I have a {} computer".format(computer_brand))

5
name ="Jared"
age = 26
shoe_size = 13
info = print("Hello my name is {}, I am {}, and my shoe size is a size {} mens".format(name,age,shoe_size))


6
a = 5
b = 2

if a > b:
    print("Hello World")

7

num = input("Please enter a number: ")

number = int(num)

if number%2 == 0:
    print("Even")
else:
    print("Odd")


8

person_name = input("Please enter your name: ")
if person_name == "Jared":
    print("Wow we have the same name")
else:
    print("How do you  even say that?")

9

person_height = input("Please enter your height in inches: ")
height = int(person_height)
minimum = 57
if height >= minimum:
    print("You are tall enough, please enjoy the ride")
else:
    print("I am sorry you are not tall enough to ride this ride")

